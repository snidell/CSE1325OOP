Useage.
Main Window provides interface to all other details including Items, Customers, and Employees
Main Window provides MavBay Revenue by all years or a selected year

Employee window provides all information on past and present employees and the Button "Get Oldest Associate" gets the longest employed associate in company

Customer menu finds all the bid information per customer given the year. The High/low button proivdes the biggest and smallest buyers of the selected year.

Item menu finds all items sold and items still being sold. Some duplicates are present between these two scroll panes as the final qty has not yet been sold but a partial qty has been
Highlight an item and the revenue, customer who bought and customer who sold it will be provided.


GUI products used:

Containers
JFrame, JList, JPanel (3)

GUI Components:
JButton, JLabel, JTextArea, JOptionPane, JComboBox (5)

GUI layoutmanagers:

BorderLayout, GridBagLayout.

*******Please Note**********
GUI is ran by case 0 in the switch statement. Therefore a 0 must be added tot he project data file